#!/bin/sh

###############################################################################
# Environment / Portability
###############################################################################

export PATH=/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin
umask 022

###############################################################################
# Global Variables
###############################################################################

ROTATERIGHT_DIR=/opt/rotateright

PRODUCT=Zoom
PRODUCT_LC=zoom
PRODUCT_UC=ZOOM
PRODUCT_VER=3.3.3
PRODUCT_REL=1
PRODUCT_OS=Linux
PRODUCT_ARCH=x86_64
PRODUCT_DIR=${ROTATERIGHT_DIR}/${PRODUCT}
INTERFACE=gui

###############################################################################
# Local Functions
###############################################################################

show_usage ()
{
	echo "Usage: $(basename ${0}) [--text] [--install_path path] [--verbose]"
	echo ""
	echo "Options:"
	echo "    --text: Use text installation."
	echo "    --install_path: Specify absolute path to base directory for install."
	echo "    --verbose: Output progress information for this script."
	echo "Note: You must uninstall any existing $PRODUCT instances before installing $PRODUCT to a custom location."
}

echo_verbose ()
{
	if [ ${VERBOSE} -eq 1 ];then
		echo $1
	fi
}
	

change_install_path_of_file ()
{
	# change the path to the RR dir
	if [ ! -f $1 ]; then
		echo "Warning: Did not locate script file: $1"
		return;
	fi 
	echo_verbose "Changing path in $1..."
	cat $1 | ${SED} -e "s:^ROTATERIGHT_DIR=.*:ROTATERIGHT_DIR=${INSTALL_DIR}:g" > $1.new
	# mv $1 $1.orig
	mv -f $1.new $1 
	chmod 755 $1 
}

change_driver_paths ()
{
	# Create temp directory to unpack oprofile tarball
	mkdir -p $1.$$ 

	# Unpack to temp dir 
	echo_verbose "Unpacking $1 driver archive..."
	${TAR} -C $1.$$ -xf $1.tar > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo "Unable to extract $1.tar."
		exit 2
	fi

	cd $1.$$
	
	change_install_path_of_file $1/install.sh
	change_install_path_of_file $1/uninstall.sh

	echo_verbose "Packing new $1 driver archive..."
	${TAR} -cf $1.tar $1 > /dev/null 2>&1

	cd ..
	# mv $1.tar $1.tar.orig
	mv -f $1.$$/$1.tar .
	rm -rf $1.$$
}

change_install_paths ()
{
	SED=`command -v sed 2> /dev/null`
	if [ $? -ne 0 ]; then
		echo "Custom installation path requires the sed tool."
		echo "Please see your operating system documentation for help installing sed."
		exit 2;
	fi
	# we need to use chrpath on the native binary because it's setuid
	CHRPATH=`command -v chrpath 2> /dev/null`
	if [ $? -ne 0 ]; then
		echo "Custom installation path requires the chrpath tool."
		echo "Please see your operating system documentation for help installing chrpath."
		exit 2;
	fi
	
	# avoid multiple installations on one machine - at least check the default location
	if [ -d $ROTATERIGHT_DIR ]; then
		echo "$ROTATERIGHT_DIR directory exists."
		echo "You must run the uninstall script for any existing $PRODUCT instances"
		echo "before installing to a custom location."
		exit 2;
	fi

	change_install_path_of_file install.sh
	change_install_path_of_file setup.sh
	change_install_path_of_file unpack200.sh
	
	# Check for package dir
	if [ ! -d "package" ]; then
		echo "Unable to find package dir."
		exit 2
	fi

	cd package

	# Check for tarball
	if [ ! -f "rotateright.tar" ]; then
		echo "Unable to find rotateright.tar."
		exit 2
	fi

	# Create temp directory to unpack tarball
	mkdir -p temp.$$ 

	# Unpack to temp dir 
	echo_verbose "Unpacking ${PRODUCT} archive..."
	${TAR} -C temp.$$ -xf rotateright.tar > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo "Unable to extract rotateright.tar."
		exit 2
	fi

	if [ ! -d "temp.$$/${PRODUCT}/bin" ]; then
		echo "Unable to find temp.$$/${PRODUCT}/bin directory."
		exit 2;
	fi

	cd temp.$$/${PRODUCT}/bin
	# change rpath of native binaries
	echo_verbose "Changing rpath of setuid binaries..."
	if [ ${PRODUCT_ARCH} = "x86_64" ]; then
		LIBDIR=lib64
	else
		LIBDIR=lib
	fi
	if [ -f ${PRODUCT_LC} ]; then
		if [ ${VERBOSE} -eq 1 ]; then
			${CHRPATH} -r "${INSTALL_DIR}/${PRODUCT}/${LIBDIR}" "${PRODUCT_LC}"
		else
			${CHRPATH} -r "${INSTALL_DIR}/${PRODUCT}/${LIBDIR}" "${PRODUCT_LC}" > /dev/null 2>&1
		fi
	fi
	if [ -f rrhotkeyd ]; then
		if [ ${VERBOSE} -eq 1 ]; then
			${CHRPATH} -r "${INSTALL_DIR}/${PRODUCT}/${LIBDIR}" rrhotkeyd
		else
			${CHRPATH} -r "${INSTALL_DIR}/${PRODUCT}/${LIBDIR}" rrhotkeyd > /dev/null 2>&1
		fi
	fi

	# back out to product dir
	cd ..

	# change the path in the wrapper script of the Java app
	change_install_path_of_file ${PRODUCT}
	# also add a command-line parameter when starting the Java app
	cat ${PRODUCT} | ${SED} -e "s:\(exec.*\)\\\:\1 -install_path ${INSTALL_DIR} \\\:" > ${PRODUCT}.new
	mv -f ${PRODUCT}.new ${PRODUCT}
	chmod 755 ${PRODUCT}

	if [ ! -d "setup" ]; then
		echo "Unable to find setup directory."
		exit 2;
	fi

	cd setup

	change_install_path_of_file install_driver.sh
	change_install_path_of_file install.sh
	change_install_path_of_file setup.sh
	change_install_path_of_file uninstall_link.sh
	change_install_path_of_file uninstall.sh

	if [ ! -d "kmod" ]; then
		echo "Unable to find kmod directory."
		exit 2;
	fi

	cd kmod

	if [ -f "oprofile.tar" ]; then	
		change_driver_paths oprofile
	fi
	if [ -f "rrprofile.tar" ]; then	
		change_driver_paths rrprofile
	fi
	if [ -f "rrnotify.tar" ]; then	
		change_driver_paths rrnotify
	fi
	# back out of kmod
	cd ..
	# back out of $PRODUCT/setup
	cd ../..

	change_install_path_of_file uninstall${PRODUCT}.sh

	# make a new tarball 
	echo_verbose "Packing new ${PRODUCT} archive..."
	${TAR} -cf rotateright.tar * > /dev/null 2>&1

	# back out of temp dir	
	cd ..
	# mv rotateright.tar rotateright.tar.orig
	mv -f temp.$$/rotateright.tar .
	rm -rf temp.$$
	
	# back out of package dir
	cd ..
}

check_for_root ()
{
	if [ "${UID}" = "" ]; then
		UID=`id -u`
	fi

	# Make sure that we are root
	if [ $UID -ne 0 ]; then
		echo "You must be root to run this script."
		exit 2
	fi
}

###############################################################################
# Commands
###############################################################################
if [ "${PRODUCT_OS}" = "FreeBSD" ]; then
	TAR=gtar
else
	TAR=tar
fi

###############################################################################
# Main
###############################################################################

VERBOSE=0
TEXT=0
CUSTOM_PATH=0
ARG_COUNT=$#

# process parameters before checking for root user
while [ $# -ne 0 ]; do
	case $1 in
	--verbose)
		VERBOSE=1
		;;
	--text)
		TEXT=1
		;;
	--install_path)
		CUSTOM_PATH=1
		if [ "$2" != "" ]; then
			case $2 in
			/*)
				;;
			*)
				echo "You must specify an absolute path for custom install."	
				show_usage
				exit 1
				;;
			esac
			INSTALL_DIR=$2
			shift
		else
			echo "You must specify a path for custom installation."
			show_usage
			exit 1
		fi
		;;
	*)
		echo "Unknown option: $1"
		show_usage
		exit 1
		;;
	esac
	shift
done


# allow running this script as regular user if launched from GUI
# or from terminal with no arguments, otherwise must have sudo/root privs.
# GUI prompt for sudo or root pw will pop up later if running as normal user
if [ ${ARG_COUNT} -gt 0 ]; then
	check_for_root
fi

INSTALLER_DIR=`pwd`

# extract installer to /tmp/rotateright-${PRODUCT_LC}-installer-XXXXX
TEMP_DIR=/tmp/rotateright-${PRODUCT_LC}-installer-$$
mkdir -p ${TEMP_DIR}
${TAR} -C ${TEMP_DIR} -xvf $INSTALLER_DIR/.install.tar > /dev/null 2>&1

printf '\n'

mkdir -p ${TEMP_DIR}/package
cp -f $INSTALLER_DIR/.rotateright.tar ${TEMP_DIR}/package/rotateright.tar

cd ${TEMP_DIR}

#Launch installer
if [ -d ${TEMP_DIR} ]; then
	trap 'echo Signal caught, cleaning up >&2; cd ${TEMP_DIR}; /bin/rm -rf ${TEMP_DIR}; exit 2' 1 2 3 15

	if [ ${CUSTOM_PATH} -eq 1 ]; then
		change_install_paths
		./install.sh run_text
	elif [ ${TEXT} -eq 1 ]; then
		./install.sh run_text
	else
		./install.sh
	fi
else
	echo "ERROR: Unable to extract to ${TEMP_DIR}"
	exit 2
fi

rm -fr ${TEMP_DIR}
exit 0

